customhost = "database-1.cizar3lczvxa.us-east-1.rds.amazonaws.com"
customuser = "aws_user"
custompass = "Bait3273"
customdb = "employee"
custombucket = "lowchoonkeat-employee1"
customregion = "us-east-1"

